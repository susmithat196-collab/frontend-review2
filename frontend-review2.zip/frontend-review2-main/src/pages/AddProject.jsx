import React, { useState } from "react";
import { useProjects } from "../contexts/ProjectContext";

const AddProject = () => {
  const { addProject } = useProjects();
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [status, setStatus] = useState("In Progress");

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!title || !description) return alert("Please fill all fields");
    const newProject = { title, description, status };
    addProject(newProject);
    setTitle("");
    setDescription("");
    setStatus("In Progress");
    alert("Project added successfully!");
  };

  return (
    <div className="max-w-lg mx-auto mt-8 p-6 bg-white shadow-lg rounded-xl">
      <h2 className="text-2xl font-semibold mb-4 text-blue-700">Add New Project</h2>
      <form onSubmit={handleSubmit}>
        <label className="block mb-2">Project Title:</label>
        <input
          type="text"
          className="w-full border p-2 rounded mb-4"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
        />
        <label className="block mb-2">Description:</label>
        <textarea
          className="w-full border p-2 rounded mb-4"
          value={description}
          onChange={(e) => setDescription(e.target.value)}
        />
        <label className="block mb-2">Status:</label>
        <select
          className="w-full border p-2 rounded mb-4"
          value={status}
          onChange={(e) => setStatus(e.target.value)}
        >
          <option>In Progress</option>
          <option>Completed</option>
          <option>On Hold</option>
        </select>
        <button
          type="submit"
          className="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600"
        >
          Add Project
        </button>
      </form>
    </div>
  );
};

export default AddProject;
