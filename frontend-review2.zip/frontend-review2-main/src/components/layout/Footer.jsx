import React from "react";

const Footer = () => {
  return (
    <footer className="bg-gray-100 text-center py-4 text-gray-700 mt-8 border-t">
      © {new Date().getFullYear()} Student Portfolio Tracker
    </footer>
  );
};

export default Footer;
