import React from "react";
import { Link, NavLink } from "react-router-dom";

const Header = () => {
  return (
    <header className="bg-white shadow-md sticky top-0 z-50">
      <div className="container mx-auto flex justify-between items-center px-6 py-4">
        <Link to="/" className="text-2xl font-bold text-blue-600">
          Student Portfolio Tracker
        </Link>

        <nav className="space-x-8">
          <NavLink
            to="/"
            className={({ isActive }) =>
              `font-medium transition-colors hover:text-blue-600 ${
                isActive ? "text-blue-600" : "text-gray-700"
              }`
            }
          >
            Home
          </NavLink>

          <NavLink
            to="/add-project"
            className={({ isActive }) =>
              `font-medium transition-colors hover:text-blue-600 ${
                isActive ? "text-blue-600" : "text-gray-700"
              }`
            }
          >
            Add Project
          </NavLink>

          <NavLink
            to="/explore"
            className={({ isActive }) =>
              `font-medium transition-colors hover:text-blue-600 ${
                isActive ? "text-blue-600" : "text-gray-700"
              }`
            }
          >
            Explore
          </NavLink>
        </nav>
      </div>
    </header>
  );
};

export default Header;
