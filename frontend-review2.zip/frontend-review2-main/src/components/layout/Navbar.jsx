import React from "react";
import { AppBar, Toolbar, Typography, Button } from "@mui/material";
import { Link } from "react-router-dom";

const Navbar = () => {
  return (
    <AppBar
      position="static"
      color="default"
      sx={{
        boxShadow: 2,
        mb: 4,
        backgroundColor: "#f8f9fa",
      }}
    >
      <Toolbar sx={{ display: "flex", justifyContent: "space-between" }}>
        <Typography variant="h6" color="primary">
          Student Portfolio Tracker
        </Typography>
        <div>
          <Button component={Link} to="/" color="primary" sx={{ mx: 1 }}>
            Home
          </Button>
          <Button component={Link} to="/add" color="primary" sx={{ mx: 1 }}>
            Add Project
          </Button>
          <Button component={Link} to="/explore" color="primary" sx={{ mx: 1 }}>
            Explore
          </Button>
        </div>
      </Toolbar>
    </AppBar>
  );
};

export default Navbar;
