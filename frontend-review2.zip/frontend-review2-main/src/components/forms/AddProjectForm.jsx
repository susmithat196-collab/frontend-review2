import React, { useState, useContext } from "react";
import { ProjectContext } from "../../contexts/ProjectContext"; // ✅ fixed path
import { useNavigate } from "react-router-dom";

function AddProject() {
  const { addProject } = useContext(ProjectContext);
  const [name, setName] = useState("");
  const [description, setDescription] = useState("");
  const [status, setStatus] = useState("In Progress");
  const navigate = useNavigate();

  const handleSubmit = (e) => {
    e.preventDefault();

    if (!name || !description) {
      alert("Please fill in all fields!");
      return;
    }

    const newProject = {
      id: Date.now(),
      name,
      description,
      status,
    };

    addProject(newProject);
    navigate("/"); // redirect to Home
  };

  return (
    <div
      style={{
        padding: "2rem",
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
      }}
    >
      <h1>Add New Project</h1>

      <form
        onSubmit={handleSubmit}
        style={{
          display: "flex",
          flexDirection: "column",
          gap: "1rem",
          maxWidth: "500px",
          width: "100%",
          background: "#f8f9fa",
          padding: "1.5rem",
          borderRadius: "8px",
          boxShadow: "0 4px 10px rgba(0,0,0,0.1)",
        }}
      >
        <label>
          <strong>Project Name:</strong>
        </label>
        <input
          type="text"
          value={name}
          onChange={(e) => setName(e.target.value)}
          placeholder="Enter project name"
          style={{
            padding: "0.6rem",
            borderRadius: "5px",
            border: "1px solid #ccc",
          }}
        />

        <label>
          <strong>Description:</strong>
        </label>
        <textarea
          value={description}
          onChange={(e) => setDescription(e.target.value)}
          placeholder="Enter project description"
          rows="4"
          style={{
            padding: "0.6rem",
            borderRadius: "5px",
            border: "1px solid #ccc",
          }}
        ></textarea>

        <label>
          <strong>Status:</strong>
        </label>
        <select
          value={status}
          onChange={(e) => setStatus(e.target.value)}
          style={{
            padding: "0.6rem",
            borderRadius: "5px",
            border: "1px solid #ccc",
          }}
        >
          <option value="In Progress">In Progress</option>
          <option value="Completed">Completed</option>
        </select>

        <button
          type="submit"
          style={{
            backgroundColor: "#007bff",
            color: "white",
            border: "none",
            padding: "0.75rem",
            borderRadius: "5px",
            cursor: "pointer",
            fontWeight: "bold",
          }}
        >
          ➕ Add Project
        </button>
      </form>
    </div>
  );
}

export default AddProject;
