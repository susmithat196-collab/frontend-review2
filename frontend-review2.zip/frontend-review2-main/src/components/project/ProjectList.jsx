import React from "react";

function ProjectList() {
  return (
    <div>
      <h2>Projects</h2>
      <p>No projects available yet.</p>
    </div>
  );
}

export default ProjectList; 
