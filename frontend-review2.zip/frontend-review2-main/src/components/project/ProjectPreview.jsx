import React from "react";

const ProjectPreview = ({ project }) => {
  if (!project) return <p>Select a project to view details.</p>;

  return (
    <div className="project-preview">
      <h2>{project.title}</h2>
      <p>{project.description}</p>
    </div>
  );
};

export default ProjectPreview;
