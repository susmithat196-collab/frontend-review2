import React from "react";
import { useProjects } from "../../contexts/ProjectContext";

const ProjectCard = ({ project }) => {
  const { deleteProject } = useProjects();

  return (
    <div className="bg-white rounded-xl shadow-md hover:shadow-xl transition-shadow duration-300 p-6">
      <h2 className="text-xl font-semibold text-gray-800 mb-2 capitalize">
        {project.title}
      </h2>
      <p className="text-gray-600 mb-3">{project.description}</p>

      <div className="flex items-center justify-between mt-4">
        <span
          className={`px-3 py-1 text-sm rounded-full ${
            project.status === "Completed"
              ? "bg-green-100 text-green-700"
              : "bg-yellow-100 text-yellow-700"
          }`}
        >
          {project.status}
        </span>

        <button
          onClick={() => deleteProject(project.id)}
          className="text-red-500 hover:bg-red-50 px-3 py-1 rounded transition"
        >
          Delete
        </button>
      </div>
    </div>
  );
};

export default ProjectCard;
