import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Navbar from "./components/layout/Navbar";
import Home from "./pages/Home";
import AddProject from "./pages/AddProject";
import Explore from "./pages/Explore"; // 👈 add this line

function App() {
  return (
    <Router>
      <Navbar />
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/add" element={<AddProject />} />
        <Route path="/explore" element={<Explore />} /> {/* 👈 add this */}
      </Routes>
    </Router>
  );
}

export default App;
